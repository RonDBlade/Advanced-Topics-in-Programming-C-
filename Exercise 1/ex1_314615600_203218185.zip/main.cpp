#include "gameManager.h"

int main(int argc, char *argv[]){
    return gameFlow(argc, argv);
}
